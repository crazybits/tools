## Brackets Extensibility

This code is used by Brackets to implement its extension management features. It is likely not useful to anyone not working with Brackets extensions.
