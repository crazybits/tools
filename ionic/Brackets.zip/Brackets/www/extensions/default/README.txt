This directory contains extensions that ship with brackets and are enabled
by default. Examples include extensions for QuickOpen.

(README also serves as a dummy file so this directory can be added to git.)
