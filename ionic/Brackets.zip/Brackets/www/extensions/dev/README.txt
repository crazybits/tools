This directory contains extensions that are being developed. User-installed
extensions are placed in the "user" extensions directory, which can be accessed
by running the Help > Show Extensions Folder menu command. The contents of
this directory (except the README file) are ignored by git.

(README also serves as a dummy file so this directory can be added to git.)
